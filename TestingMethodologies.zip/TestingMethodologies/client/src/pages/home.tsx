import { Navigation } from '@/components/navigation';
import { SearchBar } from '@/components/search-bar';
import { Overview } from '@/components/sections/overview';
import { WhiteBox } from '@/components/sections/white-box';
import { BlackBox } from '@/components/sections/black-box';
import { GrayBox } from '@/components/sections/gray-box';
import { Comparison } from '@/components/sections/comparison';
import { useSection } from '@/hooks/use-section';

export default function Home() {
  const { currentSection, navigateToSection, searchContent } = useSection();

  const renderCurrentSection = () => {
    switch (currentSection) {
      case 'white-box':
        return <WhiteBox />;
      case 'black-box':
        return <BlackBox />;
      case 'gray-box':
        return <GrayBox />;
      case 'comparison':
        return <Comparison />;
      default:
        return <Overview onNavigate={navigateToSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-background">
      <Navigation currentSection={currentSection} onNavigate={navigateToSection} />
      <SearchBar onSearch={searchContent} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentSection()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 dark:bg-gray-950 text-white py-12 mt-16 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">SQA Testing Hub</h3>
              <p className="text-gray-300">Comprehensive software quality assurance testing methodology guide for professionals and students.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-300">
                <li><button onClick={() => navigateToSection('white-box')} className="hover:text-white transition-colors">White Box Testing</button></li>
                <li><button onClick={() => navigateToSection('black-box')} className="hover:text-white transition-colors">Black Box Testing</button></li>
                <li><button onClick={() => navigateToSection('gray-box')} className="hover:text-white transition-colors">Gray Box Testing</button></li>
                <li><button onClick={() => navigateToSection('comparison')} className="hover:text-white transition-colors">Comparison</button></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Course Information</h3>
              <p className="text-gray-300">Instructor: Deni Suprihadi, S.T, M.Kom., MCE.</p>
              <p className="text-gray-300">Institution: T Informatika - UKRI</p>
              <p className="text-gray-300">Year: 2025</p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-400">&copy; 2025 SQA Testing Hub. Educational content for Software Quality Assurance.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
