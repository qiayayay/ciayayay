import { useState, useCallback } from 'react';

export type SectionType = 'overview' | 'white-box' | 'black-box' | 'gray-box' | 'comparison';

export function useSection() {
  const [currentSection, setCurrentSection] = useState<SectionType>('overview');

  const navigateToSection = useCallback((section: SectionType) => {
    setCurrentSection(section);
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const searchContent = useCallback((query: string) => {
    const searchMap: Record<string, SectionType> = {
      'white': 'white-box',
      'black': 'black-box',
      'gray': 'gray-box',
      'grey': 'gray-box',
      'comparison': 'comparison',
      'desk checking': 'white-box',
      'code walkthrough': 'white-box',
      'control flow': 'white-box',
      'data flow': 'white-box',
      'basic path': 'white-box',
      'loop testing': 'white-box',
      'boundary value': 'black-box',
      'equivalence': 'black-box',
      'decision table': 'black-box',
      'robustness': 'black-box',
      'performance': 'black-box',
      'endurance': 'black-box',
      'orthogonal': 'gray-box',
      'matrix testing': 'gray-box',
      'regression': 'gray-box',
      'pattern testing': 'gray-box'
    };

    const lowerQuery = query.toLowerCase();
    
    // Find matching section
    for (const [term, section] of Object.entries(searchMap)) {
      if (lowerQuery.includes(term)) {
        navigateToSection(section);
        break;
      }
    }
  }, [navigateToSection]);

  return {
    currentSection,
    navigateToSection,
    searchContent
  };
}
