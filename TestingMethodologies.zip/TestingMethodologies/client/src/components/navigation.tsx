import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { SectionType } from '@/hooks/use-section';

interface NavigationProps {
  currentSection: SectionType;
  onNavigate: (section: SectionType) => void;
}

export function Navigation({ currentSection, onNavigate }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'overview' as const, label: 'Overview', color: 'text-primary' },
    { id: 'white-box' as const, label: 'White Box', color: 'text-white-box' },
    { id: 'black-box' as const, label: 'Black Box', color: 'text-black-box' },
    { id: 'gray-box' as const, label: 'Gray Box', color: 'text-gray-box' },
    { id: 'comparison' as const, label: 'Comparison', color: 'text-primary' }
  ];

  const handleNavClick = (section: SectionType) => {
    onNavigate(section);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white dark:bg-card shadow-lg sticky top-0 z-50 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-gray-900 dark:text-foreground">SQA Testing Hub</h1>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentSection === item.id 
                    ? `${item.color} nav-button-active` 
                    : `text-gray-700 dark:text-gray-300 hover:${item.color}`
                }`}
              >
                {item.label}
              </Button>
            ))}
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-foreground"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white dark:bg-card border-t dark:border-border">
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => handleNavClick(item.id)}
                className={`block w-full text-left px-3 py-2 text-base font-medium transition-colors ${
                  currentSection === item.id 
                    ? `${item.color} nav-button-active` 
                    : `text-gray-700 dark:text-gray-300 hover:${item.color}`
                }`}
              >
                {item.label}
              </Button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
