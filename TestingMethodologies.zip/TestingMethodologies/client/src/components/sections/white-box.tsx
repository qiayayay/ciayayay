import { Card, CardContent } from '@/components/ui/card';

export function WhiteBox() {
  return (
    <section className="content-section">
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="w-1 h-8 bg-white-box rounded-full mr-4"></div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-foreground">White Box Testing</h1>
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive guide to White Box testing methodology, concepts, and implementation models.</p>
      </div>

      {/* Definition and Concepts */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-white-box mb-6">Definition & Concepts</h2>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">What is White Box Testing?</h3>
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <p>White box Testing adalah metode pengujian yang memeriksa dan menganalisis kode program untuk menemukan kesalahan atau kekurangan dalam suatu aplikasi atau perangkat lunak.</p>
              <p>Metode ini melibatkan pemeriksaan modul secara detail untuk memastikan keberfungsiannya dengan menggunakan runtutan logika program yang terkait pada source code.</p>
            </div>
            
            <h4 className="text-lg font-semibold text-gray-900 dark:text-foreground mt-6 mb-3">Key Characteristics:</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-white-box mr-2">•</span>
                Analyzes internal code structure and logic
              </li>
              <li className="flex items-start">
                <span className="text-white-box mr-2">•</span>
                Requires knowledge of source code
              </li>
              <li className="flex items-start">
                <span className="text-white-box mr-2">•</span>
                Tests all possible execution paths
              </li>
              <li className="flex items-start">
                <span className="text-white-box mr-2">•</span>
                Often used for unit and integration testing
              </li>
            </ul>
          </div>
          
          <div>
            <img 
              src="https://images.unsplash.com/photo-1516259762381-22954d7d3ad2?auto=format&fit=crop&w=800&h=600" 
              alt="White Box Testing Code Analysis" 
              className="w-full h-64 object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* White Box Testing Models */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-white-box mb-8">White Box Testing Models</h2>
        
        <div className="grid gap-8">
          {/* Desk Checking */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">1. Desk Checking</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-gray-700 dark:text-gray-300 mb-4">Desk Checking adalah salah satu pengujian bagi para pembuat software yang telah mempelajari bahasa pemrograman dengan sangat baik.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Focus Areas:</h4>
                <ul className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>• Logic validation and verification</li>
                  <li>• Variable value tracking</li>
                  <li>• Input and output requirement analysis</li>
                  <li>• Manual code walkthrough</li>
                </ul>
              </div>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Best Practices</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>✓ Review code line by line</li>
                  <li>✓ Track variable states</li>
                  <li>✓ Verify logic flow</li>
                  <li>✓ Check boundary conditions</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Code Walkthrough */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">2. Code Walkthrough</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-gray-700 dark:text-gray-300 mb-4">Teknik review kode secara formal atau informal yang dilakukan bersama-sama antara developer dan tim terkait untuk memahami logika kode, kemudian mengidentifikasi potensi error, dan meningkatkan kualitas keseluruhan program.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Process Steps:</h4>
                <ol className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>1. Preparation and planning</li>
                  <li>2. Team collaboration review</li>
                  <li>3. Logic understanding session</li>
                  <li>4. Error identification and documentation</li>
                </ol>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Team Benefits</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>✓ Knowledge sharing</li>
                  <li>✓ Early error detection</li>
                  <li>✓ Code quality improvement</li>
                  <li>✓ Team collaboration</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Basic Path Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">6. Basic Path Testing</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Teknik pengujian yang berfokus Identifikasi semua jalur eksekusi yang mungkin dijalankan dalam suatu program, sehingga perlu memahami alur logika aplikasi.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Cyclomatic Complexity Formula:</h4>
                <div className="code-highlight font-mono text-sm">
                  <p><strong>V(G) = E - N + 2P</strong></p>
                  <p className="text-gray-400 mt-2">Where:</p>
                  <ul className="text-gray-400 text-xs mt-1">
                    <li>E = Number of edges</li>
                    <li>N = Number of nodes</li>
                    <li>P = Number of connected components</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Implementation Steps:</h4>
                <ol className="space-y-2 text-gray-700 dark:text-gray-300">
                  <li>1. Draw control flow graph</li>
                  <li>2. Calculate cyclomatic complexity</li>
                  <li>3. Identify independent paths</li>
                  <li>4. Create test cases for each path</li>
                  <li>5. Execute and verify results</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Code Example */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-white-box mb-6">Practical Example</h2>
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Sample Code for Testing</h3>
            <pre className="code-highlight"><code>{`def calculate_grade(score):
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"

def process_student_data(students):
    results = []
    for student in students:
        if student['score'] < 0 or student['score'] > 100:
            continue
        grade = calculate_grade(student['score'])
        results.append({
            'name': student['name'],
            'score': student['score'],
            'grade': grade
        })
    return results`}</code></pre>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">White Box Test Cases</h3>
            <div className="space-y-4">
              <div className="model-box">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Path Coverage</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Test score = 95 (A grade path)</li>
                  <li>• Test score = 85 (B grade path)</li>
                  <li>• Test score = 75 (C grade path)</li>
                  <li>• Test score = 65 (D grade path)</li>
                  <li>• Test score = 55 (F grade path)</li>
                </ul>
              </div>
              <div className="model-box">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Boundary Testing</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Test score = -1 (invalid input)</li>
                  <li>• Test score = 0 (minimum valid)</li>
                  <li>• Test score = 100 (maximum valid)</li>
                  <li>• Test score = 101 (invalid input)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
