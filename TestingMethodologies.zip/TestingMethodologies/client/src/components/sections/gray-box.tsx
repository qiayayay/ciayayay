import { Card, CardContent } from '@/components/ui/card';

export function GrayBox() {
  return (
    <section className="content-section">
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="w-1 h-8 bg-gray-box rounded-full mr-4"></div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-foreground">Gray Box Testing</h1>
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive guide to Gray Box testing methodology that combines White Box and Black Box approaches.</p>
      </div>

      {/* Definition and Concepts */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-gray-box mb-6">Definition & Concepts</h2>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">What is Gray Box Testing?</h3>
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <p>Gray Box Testing adalah metode yang dipakai untuk menguji sebuah software tanpa harus memperhatikan detail software (Priyaungga et al. 2020).</p>
              <p>Teknik pengujian Gray Box Testing berfokus pada informasi dari perangkat lunak, menghasilkan test case dengan cara mempartisi masukan dan keluaran dari sebuah program dengan cara mencakup pengujian yang menyeluruh (Destiningrum & Adrian, 2017).</p>
              <p><strong>Gray Box Testing adalah Kombinasi dari Teknik Pengujian Perangkat Lunak yang Black Box Testing dan White Box Testing</strong></p>
            </div>
            
            <h4 className="text-lg font-semibold text-gray-900 dark:text-foreground mt-6 mb-3">Key Characteristics:</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-gray-box mr-2">•</span>
                Hybrid approach combining both methodologies
              </li>
              <li className="flex items-start">
                <span className="text-gray-box mr-2">•</span>
                Limited knowledge of internal structure
              </li>
              <li className="flex items-start">
                <span className="text-gray-box mr-2">•</span>
                Focus on integration and system testing
              </li>
              <li className="flex items-start">
                <span className="text-gray-box mr-2">•</span>
                Balanced test coverage approach
              </li>
            </ul>
          </div>
          
          <div>
            <img 
              src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&h=600" 
              alt="Gray Box Testing Hybrid Methodology" 
              className="w-full h-64 object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Gray Box Testing Models */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-gray-box mb-8">Gray Box Testing Models</h2>
        
        <div className="grid gap-8">
          {/* Orthogonal Array Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">1. Orthogonal Array Testing (OAT)</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Pengujian Array Ortogonal (OAT) adalah teknik pengujian perangkat lunak yang menggunakan array ortogonal untuk membuat kasus uji. Ini adalah pendekatan pengujian statistik yang sangat berguna ketika sistem yang akan diuji memiliki input data yang besar.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Implementation Steps:</h4>
                <ol className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>1. Identify independent variables</li>
                  <li>2. Find smallest array with required processes</li>
                  <li>3. Map factors to the array</li>
                  <li>4. Select values for remaining levels</li>
                  <li>5. Transcribe processes to test cases</li>
                </ol>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-4">Example: Microprocessor Testing</h4>
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                  <h5 className="font-semibold mb-2">Factors and Levels:</h5>
                  <ul className="text-sm text-gray-700 dark:text-gray-300 space-y-1">
                    <li><strong>Temperature:</strong> 100°C, 150°C, 200°C</li>
                    <li><strong>Pressure:</strong> 2 psi, 5 psi, 8 psi</li>
                    <li><strong>Doping Amount:</strong> 4%, 6%, 8%</li>
                    <li><strong>Deposition Rate:</strong> 0.1mg/s, 0.2mg/s, 0.3mg/s</li>
                  </ul>
                  <div className="mt-3 p-2 bg-white dark:bg-gray-700 rounded">
                    <p className="text-sm"><strong>Array Type:</strong> L4(3³) = 9 test cases required</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h4 className="font-semibold text-gray-900 dark:text-foreground mb-3">OAT Test Matrix Example</h4>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-gray-700">
                      <th className="px-4 py-2 text-left">Test Case</th>
                      <th className="px-4 py-2 text-center">Temperature</th>
                      <th className="px-4 py-2 text-center">Pressure</th>
                      <th className="px-4 py-2 text-center">Doping</th>
                      <th className="px-4 py-2 text-center">Deposition Rate</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    <tr>
                      <td className="px-4 py-2 border-t dark:border-gray-600">TC1</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">100°C</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">2 psi</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">4%</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">0.1mg/s</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2 border-t dark:border-gray-600">TC2</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">100°C</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">5 psi</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">6%</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">0.2mg/s</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2 border-t dark:border-gray-600">TC3</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">100°C</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">8 psi</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">8%</td>
                      <td className="px-4 py-2 border-t dark:border-gray-600 text-center">0.3mg/s</td>
                    </tr>
                    <tr className="text-gray-500">
                      <td className="px-4 py-2 border-t dark:border-gray-600" colSpan={5}>... (6 more test cases)</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Matrix Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">2. Matrix Testing</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Matrix Testing adalah teknik pengujian perangkat lunak yang sistematis dan terstruktur untuk menguji berbagai kombinasi input dan kondisi dalam suatu aplikasi. Teknik ini membantu mengidentifikasi bug yang disebabkan oleh interaksi antara parameter atau faktor yang berbeda dalam aplikasi.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Process Steps:</h4>
                <ol className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>1. Define parameters and conditions</li>
                  <li>2. Create matrix table</li>
                  <li>3. Execute test cases</li>
                  <li>4. Analyze results</li>
                </ol>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Example Scenario</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Book search application with multiple search criteria:</p>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Search by title</li>
                  <li>• Search by author</li>
                  <li>• Search by publication year</li>
                  <li>• Combined search criteria</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Regression Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">3. Regression Testing</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Regression Testing adalah teknik pengujian perangkat lunak yang berfokus pada memastikan bahwa perubahan yang dilakukan pada kode program tidak menyebabkan bug atau masalah baru pada fungsionalitas yang sudah ada.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Key Scenarios:</h4>
                <ul className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>• Adding new features</li>
                  <li>• Fixing bugs and issues</li>
                  <li>• Changing infrastructure</li>
                  <li>• Performance optimizations</li>
                </ul>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Testing Strategy</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>✓ Re-run existing test cases</li>
                  <li>✓ Verify all tests pass</li>
                  <li>✓ Test new functionality</li>
                  <li>✓ Check for side effects</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Pattern Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">4. Pattern Testing (Exploratory Testing)</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Pattern Testing, juga dikenal sebagai "Discovery Testing" atau "Exploratory Testing", adalah pendekatan pengujian perangkat lunak yang berfokus pada eksplorasi dan penemuan bug secara kreatif dan inovatif. Teknik ini menekankan pada pemikiran kritis, intuisi, dan pengalaman tester.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Testing Phases:</h4>
                <ol className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>1. Basic functionality testing</li>
                  <li>2. Boundary and unexpected scenarios</li>
                  <li>3. Performance and stability testing</li>
                  <li>4. Usability and user experience testing</li>
                </ol>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Exploration Focus</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>✓ Creative test scenarios</li>
                  <li>✓ Intuitive bug discovery</li>
                  <li>✓ User journey exploration</li>
                  <li>✓ Edge case identification</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Practical Application */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-gray-box mb-6">Practical Application: Book Management System</h2>
        <div className="grid lg:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">OAT Implementation</h3>
            <div className="space-y-3">
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Test Factors</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Book format (PDF, EPUB, Physical)</li>
                  <li>• Category (Fiction, Non-fiction, Academic)</li>
                  <li>• Language (English, Spanish, French)</li>
                  <li>• Availability (Available, Borrowed, Reserved)</li>
                </ul>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Array Analysis</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">L9(3⁴) array requires 9 test cases to cover all factor combinations efficiently.</p>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Matrix Testing Scenarios</h3>
            <div className="space-y-3">
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Search Combinations</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Title only search</li>
                  <li>• Author only search</li>
                  <li>• Year only search</li>
                  <li>• Multi-criteria combinations</li>
                </ul>
              </div>
              <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">User Permissions</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Admin user actions</li>
                  <li>• Regular user limitations</li>
                  <li>• Guest user restrictions</li>
                  <li>• Permission combinations</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Regression Testing Plan</h3>
            <div className="space-y-3">
              <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Critical Test Areas</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Book CRUD operations</li>
                  <li>• Search functionality</li>
                  <li>• User authentication</li>
                  <li>• Data export/import</li>
                </ul>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Automation Strategy</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Automated smoke tests</li>
                  <li>• Manual exploratory tests</li>
                  <li>• Performance benchmarks</li>
                  <li>• Integration checkpoints</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
