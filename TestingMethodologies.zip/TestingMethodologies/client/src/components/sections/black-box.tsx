import { Card, CardContent } from '@/components/ui/card';

export function BlackBox() {
  return (
    <section className="content-section">
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="w-1 h-8 bg-black-box rounded-full mr-4"></div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-foreground">Black Box Testing</h1>
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive guide to Black Box testing methodology focused on functionality without internal knowledge.</p>
      </div>

      {/* Definition and Concepts */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-black-box mb-6">Definition & Concepts</h2>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">What is Black Box Testing?</h3>
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <p>Black Testing adalah metode yang dipakai untuk menguji sebuah software tanpa harus memperhatikan detail software.</p>
              <p>Teknik pengujian black box testing berfokus pada informasi dari perangkat lunak, menghasilkan test case dengan cara mempartisi masukan dan keluaran dari sebuah program dengan cara mencakup pengujian yang menyeluruh.</p>
              <p>Blackbox Testing adalah Teknik Pengujian Perangkat Lunak yang melibatkan pengujian sistem tanpa mengetahui desain internalnya.</p>
            </div>
            
            <h4 className="text-lg font-semibold text-gray-900 dark:text-foreground mt-6 mb-3">Key Characteristics:</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-black-box mr-2">•</span>
                No knowledge of internal structure
              </li>
              <li className="flex items-start">
                <span className="text-black-box mr-2">•</span>
                Focus on input-output behavior
              </li>
              <li className="flex items-start">
                <span className="text-black-box mr-2">•</span>
                Requirements-based testing
              </li>
              <li className="flex items-start">
                <span className="text-black-box mr-2">•</span>
                User perspective validation
              </li>
            </ul>
          </div>
          
          <div>
            <img 
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&h=600" 
              alt="Black Box Testing User Interface" 
              className="w-full h-64 object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Black Box Testing Models */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-black-box mb-8">Black Box Testing Models</h2>
        
        <div className="grid gap-8">
          {/* Boundary Value Analysis */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">1. Boundary Value Analysis (BVA)</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-gray-700 dark:text-gray-300 mb-4">Teknik BVA digunakan untuk melakukan validasi fungsionalitas system berdasarkan persyaratan dan spesifikasi, sehingga diperlukan analisis terhadap Nilai Batas. BVA merupakan Perluasan dari Model Equivalence Partitioning, dengan memasukan nilai sedikit dari minimum dan kurang sedikit dari maksimum.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Testing Strategy:</h4>
                <ul className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>• Test values at boundaries</li>
                  <li>• Test values just inside boundaries</li>
                  <li>• Test values just outside boundaries</li>
                  <li>• Focus on edge cases and limits</li>
                </ul>
              </div>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Example Values</h4>
                <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <p><strong>Range: 1-100</strong></p>
                  <ul className="mt-2 space-y-1">
                    <li>• Invalid: 0, -1</li>
                    <li>• Valid: 1, 2, 99, 100</li>
                    <li>• Invalid: 101, 102</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Equivalence Partitioning */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">2. Equivalence Partitioning</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-gray-700 dark:text-gray-300 mb-4">Equivalence Partioning digunakan untuk mencari seluruh kesalahan atau kehilangan dalam fungsi. Kesalahan dapat tampilan struktur data atau akses menuju database serta performa. Keadaan masukan bisa berupa range, harga khusus, suatu kumpulan atau boolean.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Partition Types:</h4>
                <ul className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>• Valid input partitions</li>
                  <li>• Invalid input partitions</li>
                  <li>• Range-based partitions</li>
                  <li>• Set-based partitions</li>
                </ul>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Testing Rule</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">If input consists of several conditions, test cases should include one valid and two invalid cases.</p>
              </div>
            </div>
          </div>

          {/* Decision Table Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">3. Decision Table Testing</h3>
            <p className="text-gray-700 dark:text-gray-300 mb-4">Pengujian gabungan dari berbagai kondisi dalam pengambilan keputusan, yang digunakan pada uji software dalam verifikasi input yang beragam tetapi saling menggenapi fungsi form.</p>
            <div className="mt-4 overflow-x-auto">
              <table className="min-w-full bg-gray-50 dark:bg-gray-800 rounded-lg">
                <thead>
                  <tr className="bg-gray-100 dark:bg-gray-700">
                    <th className="px-4 py-2 text-left">Conditions</th>
                    <th className="px-4 py-2 text-center">Rule 1</th>
                    <th className="px-4 py-2 text-center">Rule 2</th>
                    <th className="px-4 py-2 text-center">Rule 3</th>
                    <th className="px-4 py-2 text-center">Rule 4</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  <tr>
                    <td className="px-4 py-2 border-t dark:border-gray-600">Valid Username</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">T</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">T</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">F</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">F</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 border-t dark:border-gray-600">Valid Password</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">T</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">F</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">T</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">F</td>
                  </tr>
                  <tr className="bg-gray-50 dark:bg-gray-800">
                    <td className="px-4 py-2 border-t dark:border-gray-600 font-semibold">Expected Result</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">Login</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">Error</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">Error</td>
                    <td className="px-4 py-2 border-t dark:border-gray-600 text-center">Error</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Performance Testing */}
          <div className="model-box">
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">8. Performance Testing</h3>
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <p className="text-gray-700 dark:text-gray-300 mb-4">Performance Testing adalah teknik pengujian perangkat lunak yang berfokus pada pengukuran dan evaluasi kinerja aplikasi dalam hal kecepatan, skalabilitas, dan stabilitas. Teknik ini penting untuk memastikan aplikasi dapat menangani beban pengguna dan memberikan kenyamanan pada pengguna secara optimal.</p>
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Key Metrics:</h4>
                <ul className="space-y-1 text-gray-700 dark:text-gray-300">
                  <li>• Response time measurement</li>
                  <li>• Throughput analysis</li>
                  <li>• Resource utilization</li>
                  <li>• Scalability testing</li>
                </ul>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Testing Tools</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• PageSpeed Insights</li>
                  <li>• DebugBear</li>
                  <li>• Pingdom</li>
                  <li>• Load testing tools</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Practical Example */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-black-box mb-6">Practical Example: E-commerce Login System</h2>
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Test Scenarios</h3>
            <div className="space-y-4">
              <div className="model-box">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Boundary Value Analysis</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Username: 1 char, 8 chars, 20 chars, 21 chars</li>
                  <li>• Password: 1 char, 6 chars, 12 chars, 13 chars</li>
                  <li>• Empty fields, null values</li>
                </ul>
              </div>
              <div className="model-box">
                <h4 className="font-semibold text-gray-800 dark:text-gray-200 mb-2">Equivalence Partitioning</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li>• Valid credentials</li>
                  <li>• Invalid username, valid password</li>
                  <li>• Valid username, invalid password</li>
                  <li>• Both invalid</li>
                </ul>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Expected Behaviors</h3>
            <div className="space-y-4">
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                <h4 className="font-semibold text-green-800 dark:text-green-400 mb-2">Valid Login</h4>
                <ul className="text-sm text-green-700 dark:text-green-300 space-y-1">
                  <li>• Redirect to dashboard</li>
                  <li>• Display welcome message</li>
                  <li>• Set session cookies</li>
                  <li>• Log successful login</li>
                </ul>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 dark:text-red-400 mb-2">Invalid Login</h4>
                <ul className="text-sm text-red-700 dark:text-red-300 space-y-1">
                  <li>• Display error message</li>
                  <li>• Stay on login page</li>
                  <li>• Clear password field</li>
                  <li>• Log failed attempt</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
