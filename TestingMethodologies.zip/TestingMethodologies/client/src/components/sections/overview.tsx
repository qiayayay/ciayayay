import { Card, CardContent } from '@/components/ui/card';
import type { SectionType } from '@/hooks/use-section';

interface OverviewProps {
  onNavigate: (section: SectionType) => void;
}

export function Overview({ onNavigate }: OverviewProps) {
  return (
    <section className="content-section">
      <div className="text-center mb-12">
        <img 
          src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
          alt="Software Quality Assurance Team" 
          className="hero-image"
        />
        <h1 className="text-4xl font-bold text-gray-900 dark:text-foreground mb-4">Software Quality Assurance</h1>
        <h2 className="text-2xl font-semibold text-gray-600 dark:text-gray-400 mb-6">Testing Methodologies Guide</h2>
        <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
          Comprehensive guide to White Box, Black Box, and Gray Box testing methodologies. 
          Learn the concepts, models, and practical applications of each testing approach.
        </p>
      </div>

      {/* Course Information */}
      <div className="definition-box">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">Course Details</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Instructor:</span>
                <span className="font-medium">Deni Suprihadi, S.T, M.Kom., MCE.</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Institution:</span>
                <span className="font-medium">T Informatika - UKRI</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Year:</span>
                <span className="font-medium">2025</span>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-foreground mb-4">Learning Objectives</h3>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                Understand testing methodology concepts
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                Master White Box testing techniques
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                Apply Black Box testing models
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">✓</span>
                Implement Gray Box testing strategies
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Testing Types Overview */}
      <div className="grid md:grid-cols-3 gap-8 mb-8">
        <div className="testing-card border-white-box" onClick={() => onNavigate('white-box')}>
          <img 
            src="https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&h=400" 
            alt="White Box Testing Code Analysis" 
            className="section-image mb-4"
          />
          <h3 className="text-xl font-semibold text-white-box mb-3">White Box Testing</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Examines internal code structure and logic flow. Tests all possible paths through the code.</p>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 bg-white-box/10 text-white-box rounded-full text-xs">Code Coverage</span>
            <span className="px-2 py-1 bg-white-box/10 text-white-box rounded-full text-xs">Path Testing</span>
            <span className="px-2 py-1 bg-white-box/10 text-white-box rounded-full text-xs">Logic Flow</span>
          </div>
        </div>

        <div className="testing-card border-black-box" onClick={() => onNavigate('black-box')}>
          <img 
            src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&h=400" 
            alt="Black Box Testing Interface" 
            className="section-image mb-4"
          />
          <h3 className="text-xl font-semibold text-black-box mb-3">Black Box Testing</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Tests functionality without knowledge of internal implementation. Focuses on input-output behavior.</p>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 bg-black-box/10 text-black-box rounded-full text-xs">Functional Testing</span>
            <span className="px-2 py-1 bg-black-box/10 text-black-box rounded-full text-xs">Boundary Values</span>
            <span className="px-2 py-1 bg-black-box/10 text-black-box rounded-full text-xs">User Experience</span>
          </div>
        </div>

        <div className="testing-card border-gray-box" onClick={() => onNavigate('gray-box')}>
          <img 
            src="https://images.unsplash.com/photo-1551836022-deb4988cc6c0?auto=format&fit=crop&w=800&h=400" 
            alt="Gray Box Testing Hybrid Approach" 
            className="section-image mb-4"
          />
          <h3 className="text-xl font-semibold text-gray-box mb-3">Gray Box Testing</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">Combines White Box and Black Box approaches. Limited knowledge of internal structure.</p>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 bg-gray-box/10 text-gray-box rounded-full text-xs">Hybrid Approach</span>
            <span className="px-2 py-1 bg-gray-box/10 text-gray-box rounded-full text-xs">Matrix Testing</span>
            <span className="px-2 py-1 bg-gray-box/10 text-gray-box rounded-full text-xs">Regression</span>
          </div>
        </div>
      </div>

      {/* Quality Assurance Standards */}
      <div className="definition-box">
        <h3 className="text-2xl font-semibold text-gray-900 dark:text-foreground mb-6">Quality Assurance Standards</h3>
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">ISO 9000 Standards</h4>
            <p className="text-gray-600 dark:text-gray-400 mb-4">International standards for quality management systems that help organizations ensure they meet customer and regulatory requirements.</p>
            <a 
              href="https://www.iso.org/obp/ui/#iso:std:iso:9000:ed-3:v1:en" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              View ISO 9000 Documentation →
            </a>
          </div>
          <div>
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&h=400" 
              alt="Quality Assurance Standards Documentation" 
              className="section-image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
