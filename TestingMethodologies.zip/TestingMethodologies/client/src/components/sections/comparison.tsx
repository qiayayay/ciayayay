import { Card, CardContent } from '@/components/ui/card';

export function Comparison() {
  return (
    <section className="content-section">
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="w-1 h-8 bg-primary rounded-full mr-4"></div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-foreground">Testing Methodologies Comparison</h1>
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-400">Comprehensive comparison of White Box, Black Box, and Gray Box testing approaches.</p>
      </div>

      {/* Comparison Table */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-primary mb-6">Detailed Comparison Matrix</h2>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b-2 border-gray-200 dark:border-gray-700">
                <th className="px-6 py-4 text-left text-gray-900 dark:text-foreground font-semibold">Aspect</th>
                <th className="px-6 py-4 text-center text-white-box font-semibold">White Box Testing</th>
                <th className="px-6 py-4 text-center text-black-box font-semibold">Black Box Testing</th>
                <th className="px-6 py-4 text-center text-gray-box font-semibold">Gray Box Testing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              <tr>
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Knowledge Required</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Complete internal structure</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">No internal knowledge</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Limited internal knowledge</td>
              </tr>
              <tr className="bg-gray-50 dark:bg-gray-800/50">
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Testing Focus</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Code paths and logic</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Functionality and requirements</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Integration and interfaces</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Testing Level</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Unit, Integration</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">System, Acceptance</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Integration, System</td>
              </tr>
              <tr className="bg-gray-50 dark:bg-gray-800/50">
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Test Coverage</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Statement, Branch, Path</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Requirements, Functionality</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Partial code + functionality</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Performed By</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Developers, Testers</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Testers, End Users</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Testers with domain knowledge</td>
              </tr>
              <tr className="bg-gray-50 dark:bg-gray-800/50">
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Time Required</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">High (detailed analysis)</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Medium (functional testing)</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Medium-High (hybrid approach)</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Cost</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">High</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Low-Medium</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Medium</td>
              </tr>
              <tr className="bg-gray-50 dark:bg-gray-800/50">
                <td className="px-6 py-4 font-semibold text-gray-900 dark:text-foreground">Automation Potential</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">High (unit tests)</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Medium (UI/API tests)</td>
                <td className="px-6 py-4 text-center text-gray-700 dark:text-gray-300">Medium-High (mixed approach)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Advantages and Disadvantages */}
      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        {/* White Box Pros/Cons */}
        <div className="definition-box border-t-4 border-white-box">
          <h3 className="text-xl font-semibold text-white-box mb-6">White Box Testing</h3>
          
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-green-700 dark:text-green-400 mb-3">✓ Advantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Complete code coverage possible
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Early defect detection
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Optimization opportunities
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Thorough testing of logic paths
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Automated unit testing
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-700 dark:text-red-400 mb-3">✗ Disadvantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Requires programming knowledge
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Time-consuming and expensive
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                May miss missing functionality
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Complex for large systems
              </li>
            </ul>
          </div>
        </div>

        {/* Black Box Pros/Cons */}
        <div className="definition-box border-t-4 border-black-box">
          <h3 className="text-xl font-semibold text-black-box mb-6">Black Box Testing</h3>
          
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-green-700 dark:text-green-400 mb-3">✓ Advantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                User perspective testing
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                No programming knowledge required
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Requirements-based validation
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Independent testing approach
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Cost-effective for functional testing
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-700 dark:text-red-400 mb-3">✗ Disadvantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Limited code coverage visibility
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                May miss implementation issues
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Difficult to identify root causes
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Redundant test cases possible
              </li>
            </ul>
          </div>
        </div>

        {/* Gray Box Pros/Cons */}
        <div className="definition-box border-t-4 border-gray-box">
          <h3 className="text-xl font-semibold text-gray-box mb-6">Gray Box Testing</h3>
          
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-green-700 dark:text-green-400 mb-3">✓ Advantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Balanced testing approach
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Better integration testing
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Combines both methodologies
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Improved test coverage
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                Suitable for web applications
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold text-red-700 dark:text-red-400 mb-3">✗ Disadvantages</h4>
            <ul className="space-y-2 text-gray-700 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Limited access to source code
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Complex test design
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Requires domain expertise
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                Higher skill requirements
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* When to Use Each Method */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-primary mb-6">When to Use Each Testing Method</h2>
        
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="border-l-4 border-white-box pl-6">
            <h3 className="text-xl font-semibold text-white-box mb-4">White Box Testing</h3>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Best Used For:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300 mb-4">
              <li>• Unit testing individual components</li>
              <li>• Security testing and vulnerability assessment</li>
              <li>• Performance optimization</li>
              <li>• Code quality analysis</li>
              <li>• Critical system components</li>
            </ul>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Project Types:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300">
              <li>• Banking and financial systems</li>
              <li>• Medical device software</li>
              <li>• Safety-critical applications</li>
              <li>• Embedded systems</li>
            </ul>
          </div>

          <div className="border-l-4 border-black-box pl-6">
            <h3 className="text-xl font-semibold text-black-box mb-4">Black Box Testing</h3>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Best Used For:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300 mb-4">
              <li>• System and acceptance testing</li>
              <li>• User interface validation</li>
              <li>• Requirements verification</li>
              <li>• Regression testing</li>
              <li>• User experience validation</li>
            </ul>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Project Types:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300">
              <li>• Web applications</li>
              <li>• Mobile applications</li>
              <li>• E-commerce platforms</li>
              <li>• Consumer software</li>
            </ul>
          </div>

          <div className="border-l-4 border-gray-box pl-6">
            <h3 className="text-xl font-semibold text-gray-box mb-4">Gray Box Testing</h3>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Best Used For:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300 mb-4">
              <li>• Integration testing</li>
              <li>• Penetration testing</li>
              <li>• Matrix and pattern testing</li>
              <li>• Regression testing</li>
              <li>• Web application testing</li>
            </ul>
            <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Project Types:</h4>
            <ul className="space-y-1 text-gray-700 dark:text-gray-300">
              <li>• Complex web systems</li>
              <li>• Enterprise applications</li>
              <li>• API testing</li>
              <li>• Microservices architecture</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Testing Strategy Recommendations */}
      <div className="definition-box">
        <h2 className="text-2xl font-semibold text-primary mb-6">Testing Strategy Recommendations</h2>
        
        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Comprehensive Testing Approach</h3>
            <div className="space-y-4">
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Phase 1: White Box Testing</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">Start with unit testing and code analysis during development phase.</p>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Phase 2: Gray Box Testing</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">Perform integration testing and system validation with limited internal knowledge.</p>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 dark:text-foreground mb-2">Phase 3: Black Box Testing</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">Conduct user acceptance testing and final validation from end-user perspective.</p>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-foreground mb-4">Best Practices</h3>
            <div className="space-y-3">
              <div className="flex items-start">
                <span className="text-primary mr-2">1.</span>
                <p className="text-gray-700 dark:text-gray-300"><strong>Risk-Based Testing:</strong> Prioritize testing based on business risk and impact.</p>
              </div>
              <div className="flex items-start">
                <span className="text-primary mr-2">2.</span>
                <p className="text-gray-700 dark:text-gray-300"><strong>Test Automation:</strong> Implement automated testing for repetitive and regression tests.</p>
              </div>
              <div className="flex items-start">
                <span className="text-primary mr-2">3.</span>
                <p className="text-gray-700 dark:text-gray-300"><strong>Documentation:</strong> Maintain comprehensive test documentation and traceability.</p>
              </div>
              <div className="flex items-start">
                <span className="text-primary mr-2">4.</span>
                <p className="text-gray-700 dark:text-gray-300"><strong>Continuous Testing:</strong> Integrate testing into CI/CD pipelines for continuous feedback.</p>
              </div>
              <div className="flex items-start">
                <span className="text-primary mr-2">5.</span>
                <p className="text-gray-700 dark:text-gray-300"><strong>Team Collaboration:</strong> Foster collaboration between developers, testers, and stakeholders.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
